# jp-business-card-detection > 2025-12-17 4:18pm
https://universe.roboflow.com/learn-yolov11/jp-business-card-detection

Provided by a Roboflow user
License: CC BY 4.0

